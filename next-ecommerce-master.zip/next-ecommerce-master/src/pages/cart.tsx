import ShoppingCart from "@/components/shopping-cart";

import Layout from "../layouts/Main";

const Products = () => (
  <Layout>
    <ShoppingCart />
  </Layout>
);

export default Products;
